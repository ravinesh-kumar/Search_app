import pandas as pd
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dish_search_app.settings')
django.setup()

from search_app.models import Dish

csv_file = 'restaurants_small.csv'

data = pd.read_csv(csv_file)
for index, row in data.iterrows():
    Dish.objects.create(
        id=row['id'],
        name=row['name'],
        location=row['location'],
        items=row['items'],
        lat_long=row['lat_long'],
        full_details=row['full_details']
    )
"""
xit
git branch -M main
git push -u origin main
"""